package tn.societe.gestion;

import java.util.List;

public class Main {
    public static void main(String[] args) {

        // ============================
        //   GESTION DES EMPLOYÉS
        // ============================

        GestionEmploye gestion = new GestionEmploye();


        Employe e1 = new Employe(3, "Ben", "Ahmed", "Informatique", 2);
        Employe e2 = new Employe(1, "Trabelsi", "Sana", "RH", 1);
        Employe e3 = new Employe(2, "Hassine", "Ali", "Finance", 3);
        Employe e4 = new Employe(4, "Saidi", "Amira", "Informatique", 1);


        gestion.ajouterEmploye(e1);
        gestion.ajouterEmploye(e2);
        gestion.ajouterEmploye(e3);
        gestion.ajouterEmploye(e4);

        System.out.println("=== Tous les employés ===");
        gestion.displayEmploye();


        String deptRecherche = "Informatique";
        List<Employe> employesDept = gestion.rechercherParDepartement(deptRecherche);

        System.out.println("\n=== Employés du département '" + deptRecherche + "' ===");
        employesDept.forEach(System.out::println);


        // ============================
        //   GESTION DES DÉPARTEMENTS
        // ============================

        DepartementHashSet gestionDept = new DepartementHashSet();

        Departement d1 = new Departement(1, "Informatique", 25);
        Departement d2 = new Departement(2, "RH", 12);
        Departement d3 = new Departement(3, "Finance", 18);

        gestionDept.ajouterDepartement(d1);
        gestionDept.ajouterDepartement(d2);
        gestionDept.ajouterDepartement(d3);

        System.out.println("\n=== Tous les départements ===");
        gestionDept.afficherDepartements();

        System.out.println("\n=== Tri par ID ===");
        gestionDept.trierDepartementsParId();

        System.out.println("\n=== Tri par Nom + Nombre Employés ===");
        gestionDept.trierDepartementsParNomEtNombreEmployes();
    }
}
