package tn.societe.gestion;

public class Main {
    public static void main(String[] args) {
        GestionEmploye gestion = new GestionEmploye();

        // Création des employés
        Employe e1 = new Employe(3, "Ben", "Ahmed", "Informatique", 2);
        Employe e2 = new Employe(1, "Trabelsi", "Sana", "RH", 1);
        Employe e3 = new Employe(2, "Hassine", "Ali", "Finance", 3);

        // Ajout des employés
        gestion.ajouterEmploye(e1);
        gestion.ajouterEmploye(e2);
        gestion.ajouterEmploye(e3);

        System.out.println("=== Avant tri ===");
        gestion.displayEmploye();

        // Tri par ID
        gestion.trierEmployeParId();
        System.out.println("\n=== Après tri par ID ===");
        gestion.displayEmploye();

        // Tri par nom, département et grade
        gestion.trierEmployeParNomDépartementEtGrade();
        System.out.println("\n=== Après tri par nom, département et grade ===");
        gestion.displayEmploye();

        // Recherche par nom ou prénom
        String recherche = "Sana";
        boolean trouve = gestion.rechercherEmploye(recherche);
        System.out.println("\nRecherche employé par nom ou prénom '" + recherche + "' : " + trouve);

        // Suppression d'un employé
        gestion.supprimerEmploye(e2);
        System.out.println("\n=== Après suppression de " + e2.getPrenom() + " ===");
        gestion.displayEmploye();
    }
}
