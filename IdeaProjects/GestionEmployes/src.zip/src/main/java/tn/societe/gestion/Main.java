package tn.societe.gestion;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        GestionEmploye gestion = new GestionEmploye();

        // Création des employés
        Employe e1 = new Employe(3, "Ben", "Ahmed", "Informatique", 2);
        Employe e2 = new Employe(1, "Trabelsi", "Sana", "RH", 1);
        Employe e3 = new Employe(2, "Hassine", "Ali", "Finance", 3);
        Employe e4 = new Employe(4, "Saidi", "Amira", "Informatique", 1);

        // Ajout des employés
        gestion.ajouterEmploye(e1);
        gestion.ajouterEmploye(e2);
        gestion.ajouterEmploye(e3);
        gestion.ajouterEmploye(e4);

        System.out.println("=== Tous les employés ===");
        gestion.displayEmploye();

        // Recherche avancée par département
        String deptRecherche = "Informatique";
        List<Employe> employesDept = gestion.rechercherParDepartement(deptRecherche);

        System.out.println("\n=== Employés du département '" + deptRecherche + "' ===");
        employesDept.forEach(System.out::println);
    }
}
